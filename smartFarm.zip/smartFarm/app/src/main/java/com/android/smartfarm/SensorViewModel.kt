package com.android.smartfarm

import androidx.lifecycle.ViewModel

class SensorViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}